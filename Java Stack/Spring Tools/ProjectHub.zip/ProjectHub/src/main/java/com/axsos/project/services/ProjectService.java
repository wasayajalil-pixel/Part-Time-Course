package com.axsos.project.services;

import java.util.List;

import org.springframework.stereotype.Service;

import com.axsos.game.models.Game;
import com.axsos.project.models.Project;
import com.axsos.project.repositories.ProjectRepository;

@Service
public class ProjectService {
	private final ProjectRepository projectRepository;

	public ProjectService(ProjectRepository projectRepository) {
		this.projectRepository = projectRepository;
	}
	
	public List<Project> allProjects() {
	        return projectRepository.findAllByOrderByCreatedAtDesc();
	    }

	    public Project createProject(Project project) {
	        return projectRepository.save(project);
	    }

	    public Project findProject(Long id) {
	        return projectRepository.findById(id).orElse(null);
	    }

	    public Project updateProject(Project project) {
	        return projectRepository.save(project);
	    }

	    public void deleteProject(Long id) {
	        projectRepository.deleteById(id);
	    }
	    
	  //Sort games
		public List<Project> sortGames(String sortBy) {

			if (sortBy == null) {
				return (List<Project>) projectRepository.findAll();
			}

			if (sortBy.equals("title")) {
				return projectRepository.findAllByOrderByTitleAsc();
			}

			if (sortBy.equals("technology")) {
				return projectRepository.findAllByOrderByTitleAsc();
			}

			if (sortBy.equals("releaseDate")) {
				return projectRepository.findAllByOrderByReleaseDateAsc();
			}

			return (List<Project>) projectRepository.findAll();
		}
	

}


