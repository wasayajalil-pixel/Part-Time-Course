# SmartSpend X — AI Financial Intelligence Platform

A professional Django project for tracking expenses, budgets, bills, goals, receipt uploads, charts, and AI-style financial insights.

## Features

- Professional fintech landing page
- Register / Login / Logout
- Dashboard with KPIs and Chart.js chart
- Expense CRUD with receipt image upload
- Budget planning
- Bill reminders
- Savings goals with progress bars
- AI Insights page
- Responsive dark cyber-neobank design
- Ready for future OCR, Visa, APIs, and AI integration

## Tech Stack

- Python
- Django
- SQLite by default
- HTML / CSS / JavaScript
- Chart.js
- Pillow for receipt uploads

## How to Run

```bash
python -m venv env
```

Windows:

```bash
env\Scripts\activate
```

Mac/Linux:

```bash
source env/bin/activate
```

Install requirements:

```bash
pip install -r requirements.txt
```

Run migrations:

```bash
python manage.py makemigrations
python manage.py migrate
```

Start server:

```bash
python manage.py runserver
```

Open:

```text
http://127.0.0.1:8000/
```

## Suggested Next Improvements

- OCR receipt scanner using Tesseract or Google Vision API
- OpenAI/Gemini financial assistant
- Visa/bank transaction API integration
- Multi-currency support
- PDF/Excel export
- Deployment on Render or AWS
