from django.contrib import admin
from .models import Category, Expense, Budget, Bill, Goal
admin.site.register([Category,Expense,Budget,Bill,Goal])
