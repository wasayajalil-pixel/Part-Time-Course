from django.urls import path
from . import views
urlpatterns=[
    path('', views.landing, name='landing'),
    path('register/', views.register_view, name='register'),
    path('login/', views.login_view, name='login'),
    path('logout/', views.logout_view, name='logout'),
    path('dashboard/', views.dashboard, name='dashboard'),
    path('expenses/', views.expenses, name='expenses'),
    path('expenses/<int:expense_id>/delete/', views.delete_expense, name='delete_expense'),
    path('budgets/', views.budgets, name='budgets'),
    path('bills/', views.bills, name='bills'),
    path('goals/', views.goals, name='goals'),
    path('ai-insights/', views.ai_insights, name='ai_insights'),
]
