from decimal import Decimal
from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.db.models import Sum
from django.utils import timezone
from .models import Category, Expense, Budget, Bill, Goal
from .forms import RegisterForm, ExpenseForm, BudgetForm, BillForm, GoalForm

DEFAULT_CATEGORIES=[('Food','🍔','#22C55E'),('Transport','🚕','#38BDF8'),('Shopping','🛍️','#A855F7'),('Bills','🧾','#F59E0B'),('Health','💊','#EF4444'),('Entertainment','🎮','#EC4899')]

def ensure_categories(user):
    for name, icon, color in DEFAULT_CATEGORIES:
        Category.objects.get_or_create(user=user, name=name, defaults={'icon':icon,'color':color})

def landing(request):
    return render(request,'finance/landing.html')

def register_view(request):
    if request.method=='POST':
        form=RegisterForm(request.POST)
        if form.is_valid():
            user=User.objects.create_user(username=form.cleaned_data['username'], email=form.cleaned_data['email'], password=form.cleaned_data['password'], first_name=form.cleaned_data['first_name'], last_name=form.cleaned_data['last_name'])
            ensure_categories(user)
            messages.success(request,'Account created successfully. Please login.')
            return redirect('login')
    else: form=RegisterForm()
    return render(request,'finance/auth.html',{'form':form,'mode':'register'})

def login_view(request):
    if request.method=='POST':
        user=authenticate(request, username=request.POST.get('username'), password=request.POST.get('password'))
        if user:
            login(request,user); ensure_categories(user); return redirect('dashboard')
        messages.error(request,'Invalid username or password')
    return render(request,'finance/auth.html',{'mode':'login'})

def logout_view(request):
    logout(request); return redirect('landing')

@login_required
def dashboard(request):
    ensure_categories(request.user)
    expenses=Expense.objects.filter(user=request.user).order_by('-expense_date')
    total=expenses.aggregate(Sum('amount'))['amount__sum'] or Decimal('0')
    month_total=expenses.filter(expense_date__month=timezone.now().month).aggregate(Sum('amount'))['amount__sum'] or Decimal('0')
    bills_due=Bill.objects.filter(user=request.user,is_paid=False).count()
    categories=Category.objects.filter(user=request.user)
    labels=[]; values=[]
    for c in categories:
        s=expenses.filter(category=c).aggregate(Sum('amount'))['amount__sum'] or 0
        if s: labels.append(c.name); values.append(float(s))
    ai_tip='Great job! Keep tracking your expenses daily to improve your financial score.'
    if month_total > 1000: ai_tip='Your monthly spending is high. Review Food and Shopping categories to save more.'
    elif month_total > 500: ai_tip='You are doing okay. Try setting a weekly saving challenge.'
    return render(request,'finance/dashboard.html',{'expenses':expenses[:6],'total':total,'month_total':month_total,'bills_due':bills_due,'labels':labels,'values':values,'ai_tip':ai_tip,'goals':Goal.objects.filter(user=request.user)[:3]})

@login_required
def expenses(request):
    ensure_categories(request.user)
    form=ExpenseForm(request.POST or None, request.FILES or None)
    form.fields['category'].queryset=Category.objects.filter(user=request.user)
    if request.method=='POST' and form.is_valid():
        expense=form.save(commit=False); expense.user=request.user; expense.save(); messages.success(request,'Expense added successfully'); return redirect('expenses')
    return render(request,'finance/expenses.html',{'form':form,'expenses':Expense.objects.filter(user=request.user).order_by('-expense_date')})

@login_required
def delete_expense(request, expense_id):
    get_object_or_404(Expense,id=expense_id,user=request.user).delete(); messages.success(request,'Expense deleted'); return redirect('expenses')

@login_required
def budgets(request):
    ensure_categories(request.user)
    form=BudgetForm(request.POST or None); form.fields['category'].queryset=Category.objects.filter(user=request.user)
    if request.method=='POST' and form.is_valid():
        b=form.save(commit=False); b.user=request.user; b.save(); return redirect('budgets')
    return render(request,'finance/budgets.html',{'form':form,'budgets':Budget.objects.filter(user=request.user)})

@login_required
def bills(request):
    form=BillForm(request.POST or None)
    if request.method=='POST' and form.is_valid():
        bill=form.save(commit=False); bill.user=request.user; bill.save(); return redirect('bills')
    return render(request,'finance/bills.html',{'form':form,'bills':Bill.objects.filter(user=request.user).order_by('due_date')})

@login_required
def goals(request):
    form=GoalForm(request.POST or None)
    if request.method=='POST' and form.is_valid():
        goal=form.save(commit=False); goal.user=request.user; goal.save(); return redirect('goals')
    return render(request,'finance/goals.html',{'form':form,'goals':Goal.objects.filter(user=request.user)})

@login_required
def ai_insights(request):
    expenses=Expense.objects.filter(user=request.user)
    total=expenses.aggregate(Sum('amount'))['amount__sum'] or Decimal('0')
    top=expenses.values('category__name').annotate(total=Sum('amount')).order_by('-total').first()
    insights=[
        'Your financial score improves when you log expenses daily.',
        'Try the 50/30/20 rule: needs, wants, and savings.',
        'Set alerts for bills to avoid late payments.'
    ]
    if top: insights.insert(0, f"Your highest spending category is {top['category__name']} with {top['total']} total.")
    return render(request,'finance/ai_insights.html',{'insights':insights,'total':total})
