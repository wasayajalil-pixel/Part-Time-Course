from django import forms
from django.contrib.auth.models import User
from .models import Expense, Budget, Bill, Goal

class RegisterForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder':'Password'}))
    confirm_password = forms.CharField(widget=forms.PasswordInput(attrs={'placeholder':'Confirm password'}))
    class Meta:
        model = User
        fields = ['first_name','last_name','username','email','password']
        widgets = {f: forms.TextInput(attrs={'placeholder':f.replace('_',' ').title()}) for f in ['first_name','last_name','username']}
    def clean(self):
        data=super().clean()
        if data.get('password') != data.get('confirm_password'):
            raise forms.ValidationError('Passwords do not match')
        if User.objects.filter(email=data.get('email')).exists():
            raise forms.ValidationError('Email already exists')
        return data

class ExpenseForm(forms.ModelForm):
    class Meta:
        model=Expense
        fields=['category','title','amount','merchant','notes','receipt','expense_date']
        widgets={'expense_date':forms.DateInput(attrs={'type':'date'}), 'notes':forms.Textarea(attrs={'rows':3})}

class BudgetForm(forms.ModelForm):
    class Meta:
        model=Budget
        fields=['category','limit_amount','month']
        widgets={'month':forms.TextInput(attrs={'placeholder':'June 2026'})}

class BillForm(forms.ModelForm):
    class Meta:
        model=Bill
        fields=['name','amount','due_date','is_paid']
        widgets={'due_date':forms.DateInput(attrs={'type':'date'})}

class GoalForm(forms.ModelForm):
    class Meta:
        model=Goal
        fields=['name','target_amount','saved_amount','deadline']
        widgets={'deadline':forms.DateInput(attrs={'type':'date'})}
